.\objects\uartstdio.o: ..\uartstdio.c
.\objects\uartstdio.o: D:\Keil 5\ARM\ARMCC\Bin\..\include\stdbool.h
.\objects\uartstdio.o: D:\Keil 5\ARM\ARMCC\Bin\..\include\stdint.h
.\objects\uartstdio.o: D:\Keil 5\ARM\ARMCC\Bin\..\include\stdarg.h
.\objects\uartstdio.o: ..\ti/devices/msp432e4/driverlib/driverlib.h
.\objects\uartstdio.o: D:\Keil 5\ARM\PACK\TexasInstruments\MSP432E4_DFP\3.2.6\Device\Include\msp.h
.\objects\uartstdio.o: D:\Keil 5\ARM\PACK\TexasInstruments\MSP432E4_DFP\3.2.6\Device\Include\msp432e401y.h
.\objects\uartstdio.o: D:\Keil 5\ARM\PACK\ARM\CMSIS\5.4.0\CMSIS\Core\Include\core_cm4.h
.\objects\uartstdio.o: D:\Keil 5\ARM\PACK\ARM\CMSIS\5.4.0\CMSIS\Core\Include\cmsis_version.h
.\objects\uartstdio.o: D:\Keil 5\ARM\PACK\ARM\CMSIS\5.4.0\CMSIS\Core\Include\cmsis_compiler.h
.\objects\uartstdio.o: D:\Keil 5\ARM\PACK\ARM\CMSIS\5.4.0\CMSIS\Core\Include\cmsis_armcc.h
.\objects\uartstdio.o: D:\Keil 5\ARM\PACK\ARM\CMSIS\5.4.0\CMSIS\Core\Include\mpu_armv7.h
.\objects\uartstdio.o: D:\Keil 5\ARM\PACK\TexasInstruments\MSP432E4_DFP\3.2.6\Device\Include\system_msp432e401y.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\adc.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\aes.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\can.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\comp.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\cpu.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\crc.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\debug.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\des.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\eeprom.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\emac.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\epi.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\flash.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\fpu.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\gpio.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\hibernate.h
.\objects\uartstdio.o: D:\Keil 5\ARM\ARMCC\Bin\..\include\time.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\i2c.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\interrupt.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\mpu.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\pin_map.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\pwm.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\qei.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\rom.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\rom_map.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\shamd5.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\ssi.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\sw_crc.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\sysctl.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\sysexc.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\systick.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\timer.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\types.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\uart.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\udma.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\usb.h
.\objects\uartstdio.o: ..\ti\devices\msp432e4\driverlib\watchdog.h
.\objects\uartstdio.o: ..\uartstdio.h
