//*****************************************************************************
//
// MSP432 main.c template - P1.0 and P2.0-2 ports toggle
//
//****************************************************************************

#include "msp.h"

volatile uint32_t msTicks;                      /* counts 1ms timeTicks       */

void LEDinit(void){  // WDT_A->CTL = WDT_A_CTL_PW | WDT_A_CTL_HOLD;           // Stop watchdog timer

 // Enable GPION peripheral
	SYSCTL->RCGCGPIO |= SYSCTL_RCGCGPIO_R12;

	// Check if the peripheral access is enabled.
	while(!(SYSCTL->PRGPIO & SYSCTL_PRGPIO_R12));

	/* Enable the GPIO pin for the LED (PN0). */

	// Set drive strength
	GPION->DR2R |= BIT0;
	GPION->DR4R &= ~(BIT0);
	GPION->DR8R &= ~(BIT0);
	GPION->SLR &= ~(BIT0);
	// Set pin type
	GPION->ODR &= ~(BIT0);
	GPION->PUR &= ~(BIT0);
	GPION->PDR &= ~(BIT0);
	GPION->DEN |= BIT0;
	// Set the analog mode select register.
	GPION->AMSEL &= ~(BIT0);
	// Set the pin direction and mode.
	GPION->DIR |= BIT0;
	GPION->AFSEL &= ~(BIT0);

/* Enable the GPIO pin for the LED (PN1). */

	// Set drive strength
	GPION->DR2R |= BIT1;
	GPION->DR4R &= ~(BIT1);
	GPION->DR8R &= ~(BIT1);
	GPION->SLR &= ~(BIT1);
	// Set pin type
	GPION->ODR &= ~(BIT1);
	GPION->PUR &= ~(BIT1);
	GPION->PDR &= ~(BIT1);
	GPION->DEN |= BIT1;
	// Set the analog mode select register.
	GPION->AMSEL &= ~(BIT1);
	// Set the pin direction and mode.
	GPION->DIR |= BIT1;
	GPION->AFSEL &= ~(BIT1);
}
/*----------------------------------------------------------------------------
  SysTick_Handler
 *----------------------------------------------------------------------------*/
void SysTick_Handler(void) {
  msTicks++;
}

/*----------------------------------------------------------------------------
  delays number of tick Systicks (happens every 1 ms)
 *----------------------------------------------------------------------------*/
void Delay (uint32_t dlyTicks) {                                              
  uint32_t curTicks;
  curTicks = msTicks;
  while ((msTicks - curTicks) < dlyTicks);
}

int main(void)
{
	SysTick_Config(SystemCoreClock / 1000);       /* Systick interrupt each 1ms */
	LEDinit();
    while(1)
    {
      GPION->DATA ^= BIT0;  // D1 Green Toggle
			Delay(500);						// Delay 500 msec (500 times 1 SysTick interrupt)
			GPION->DATA ^= BIT1;  // D2 Green Toggle
			Delay(500);						// Delay 500 msec (500 times 1 SysTick interrupt)

    }
}
